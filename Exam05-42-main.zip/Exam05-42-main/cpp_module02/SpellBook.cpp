#include "SpellBook.hpp"

SpellBook::SpellBook() {}
SpellBook::~SpellBook() {}

void SpellBook::learnSpell(ASpell* al)
{
	if (al)
		spl[al->getName()] = al;
}

void SpellBook::forgetSpell(std::string const &s)
{
	spl.erase(s);
}

ASpell* SpellBook::createSpell(std::string const &s)
{
	std::map <std::string, ASpell *>::iterator it = spl.find(s);
	if (it != spl.end())
		return spl[s];
	return NULL;
}