#include "TargetGenerator.hpp"

TargetGenerator::TargetGenerator() {}
TargetGenerator::~TargetGenerator() {}

void TargetGenerator::learnTargetType(ATarget* al)
{
	if (al)
		spl[al->getType()] = al;
}

void TargetGenerator::forgetTargetType(std::string const &s)
{
	spl.erase(s);
}

ATarget* TargetGenerator::createTarget(std::string const &s)
{
	std::map <std::string, ATarget *>::iterator it = spl.find(s);
	if (it != spl.end())
		return spl[s];
	return NULL;
}